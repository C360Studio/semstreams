#!/usr/bin/env python3
"""Bounded, serial one-off pilot. Never mutates the source checkout.

Run with Python 3 from any directory. Optional output directory is positional.
All source inputs come from BASE, not the current worktree. Runtime copies are
retained at the recorded /tmp path for inspection; only owned processes are killed.
"""
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
BASE = '84fc01e46c104d890bffe32b0046e72f006df454'
OUT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else HERE / 'evidence'
OUT.mkdir(exist_ok=False)
RUNTIME = Path(tempfile.mkdtemp(prefix='semstreams-ooze-pilot-'))
ENV = dict(os.environ, GOMAXPROCS='2', GOFLAGS='-p=2', GOTOOLCHAIN='local')
SUMMARY = []


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')


def hashes(root):
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob('*')) if p.is_file()}


def command(name, args, cwd, env=ENV, timeout=60):
    start = time.monotonic()
    result = subprocess.run(args, cwd=cwd, env=env, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, timeout=timeout)
    (OUT / (name+'.log')).write_bytes(result.stdout)
    record = {'name': name, 'command': args, 'cwd': str(cwd), 'returncode': result.returncode,
              'seconds': round(time.monotonic()-start, 3)}
    SUMMARY.append(record)
    write(OUT / 'commands.json', SUMMARY)
    print(name, result.returncode, record['seconds'], flush=True)
    return result


def alive(pid):
    result = subprocess.run(['ps', '-o', 'stat=', '-p', str(pid)], stdout=subprocess.PIPE)
    return result.returncode == 0 and result.stdout.strip() and not result.stdout.strip().startswith(b'Z')


def processes(run):
    result = []
    for path in sorted(run.glob('candidate-*/process.json')):
        record = json.loads(path.read_text())
        for field in ('pid', 'descendant_pid'):
            if field in record:
                result.append({'pid': record[field], 'field': field, 'alive': bool(alive(record[field])),
                               'pgid': record['pgid']})
    return result


def run_ooze(name, subject, target, operator='comparison', selector='.', mode='test', timeout='10s',
             cancel=False, missing=False, deadline=90):
    run = OUT / name
    run.mkdir()
    temp = RUNTIME / (name+'-tmp')
    temp.mkdir()
    test_command = ['go', 'test', '-json', '-count=1', '-parallel=1', '-timeout='+timeout,
                    '-run='+selector, './...']
    if target.startswith('pkg/'):
        test_command = test_command[:-1] + ['./pkg/types', '-rapid.seed=1318', '-rapid.nofailfile']
    ignore = r'^(pkg/errs/|pkg/retry/)|^pkg/types/(?!entity_id\.go$)'
    # RE2 has no lookahead. Explicit filenames are compiled from the source set.
    ignore = '^(' + '|'.join(__import__('re').escape(str(p.relative_to(subject)))
                           for p in sorted(subject.rglob('*.go'))
                           if str(p.relative_to(subject)) != target and not p.name.endswith('_test.go')) + ')$'
    if ignore == '^()$': ignore = '^never-matches$'
    env = dict(ENV, PILOT_SUBJECT=str(subject), PILOT_TARGET=target, PILOT_OPERATOR=operator,
               PILOT_COMMAND='missing-ooze-pilot-executable' if missing else sys.executable+' '+str(HERE/'child.py'),
               PILOT_IGNORE=ignore, PILOT_RUN=str(run), PILOT_CHILD_MODE=mode,
               PILOT_TEST_COMMAND=json.dumps(test_command), TMPDIR=str(temp))
    before = hashes(subject)
    args = [str(RUNTIME/'pilot.test'), '-test.v', '-test.run=^TestOoze$', '-test.timeout=18m']
    write(run/'manifest.json', {'command': args, 'test_command': test_command, 'operator': operator,
          'ignore_regex': ignore, 'subject': str(subject), 'target': target, 'source_before': before,
          'mode': mode, 'deadline_seconds': deadline, 'cancel': cancel, 'missing_command': missing,
          'environment': {k:env[k] for k in ('GOMAXPROCS','GOFLAGS','GOTOOLCHAIN','TMPDIR','PILOT_COMMAND')}})
    start = time.monotonic()
    intervention = None
    with (run/'ooze.log').open('wb') as log:
        process = subprocess.Popen(args, cwd=HERE/'harness', env=env, stdout=log,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        while process.poll() is None:
            elapsed = time.monotonic()-start
            ready = any('descendant_pid' in json.loads(p.read_text()) for p in run.glob('candidate-*/process.json'))
            if cancel and ready and intervention is None:
                process.send_signal(signal.SIGINT)
                intervention = 'SIGINT to pilot test PID (ordinary cancellation probe)'
            if elapsed > deadline:
                os.killpg(process.pid, signal.SIGKILL)
                intervention = 'outer deadline SIGKILL pilot process group'
                break
            time.sleep(0.1)
        process.wait(timeout=5)
    time.sleep(0.2)
    before_cleanup = processes(run)
    for item in before_cleanup:
        if item['alive']:
            try: os.kill(item['pid'], signal.SIGKILL)
            except ProcessLookupError: pass
    time.sleep(0.2)
    after_cleanup = processes(run)
    leftovers = sorted(str(p) for p in temp.glob('ooze-*'))
    # Cleanup only Ooze directories inside the unique directory created for this run.
    for path in leftovers: shutil.rmtree(path)
    result = {'returncode': process.returncode, 'seconds': round(time.monotonic()-start,3),
              'intervention': intervention, 'processes_before_owned_cleanup': before_cleanup,
              'processes_after_owned_cleanup': after_cleanup, 'temporary_dirs_before_owned_cleanup': leftovers,
              'temporary_dirs_after_owned_cleanup': sorted(str(p) for p in temp.glob('ooze-*')),
              'source_after': hashes(subject), 'source_unchanged': before == hashes(subject)}
    write(run/'result.json', result)
    print(name, process.returncode, result['seconds'], 'source_unchanged', result['source_unchanged'], flush=True)
    return run


files = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', BASE, '--',
             'go.mod', 'go.sum', 'pkg/types', 'pkg/errs', 'pkg/retry'], cwd=REPO).decode().splitlines()
subject = RUNTIME/'subject'
for file in files:
    dest = subject/file
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(subprocess.check_output(['git', 'show', BASE+':'+file], cwd=REPO))
write(OUT/'source-manifest.json', {'base': BASE, 'files': hashes(subject), 'runtime': str(RUNTIME),
      'environment': {k: ENV[k] for k in ('GOMAXPROCS','GOFLAGS','GOTOOLCHAIN')},
      'go_version': subprocess.check_output(['go','version'], env=ENV).decode().strip(),
      'copied_files_match_git': True})
for name in ('go.mod','go.sum'):
    shutil.copyfile(subject/name, OUT/('subject-'+name+'.txt'))
if command('harness-dependencies', ['go','mod','tidy'], HERE/'harness', timeout=180).returncode:
    sys.exit('harness dependency failure')
if command('harness-build', ['go','test','-c','-o',str(RUNTIME/'pilot.test')], HERE/'harness', timeout=180).returncode:
    sys.exit('harness build failure')
TEST = ['go','test','-json','-count=1','-parallel=1','-timeout=10s','./pkg/types',
        '-rapid.seed=1318','-rapid.nofailfile']
if command('baseline', TEST, subject, timeout=90).returncode: sys.exit('baseline failed')
command('warm-baseline', TEST, subject)
run_ooze('positive', subject, 'pkg/types/entity_id.go', 'boundary', '^TestPropEntityIDByteBound$')
run_ooze('negative', subject, 'pkg/types/entity_id.go', 'boundary', '^TestPropEntityIDRoundTrip$')
run_ooze('restored-coverage', subject, 'pkg/types/entity_id.go', 'boundary', '^TestPropEntityIDByteBound$')

fixture = RUNTIME/'fixture'
fixture.mkdir()
(fixture/'go.mod').write_text('module fixture\n\ngo 1.26.3\n')
(fixture/'fixture.go').write_text('package fixture\n\nfunc Less(x int) bool { return x < 5 }\n')
(fixture/'fixture_test.go').write_text('package fixture\nimport "testing"\nfunc TestLess(t *testing.T) { if !Less(4) || Less(5) { t.Fatal("boundary assertion") } }\n')
write(OUT/'fixture-manifest.json', {'files': {str(p.relative_to(fixture)):p.read_text() for p in fixture.iterdir()}})
command('fixture-baseline', ['go','test','-json','-count=1','-timeout=5s','./...'],fixture)
run_ooze('invalid-build', fixture, 'fixture.go', 'invalid')
run_ooze('command-exit', fixture, 'fixture.go', mode='exit')
run_ooze('missing-command', fixture, 'fixture.go', missing=True)
run_ooze('zero-tests', fixture, 'fixture.go', selector='^NoSuchTest$')
zero = RUNTIME/'zero'; shutil.copytree(fixture,zero)
(zero/'fixture.go').write_text('package fixture\n\nfunc Less(x int) bool { return true }\n')
run_ooze('zero-mutations', zero, 'fixture.go')
slow = RUNTIME/'timeout'; shutil.copytree(fixture,slow)
(slow/'fixture_test.go').write_text('package fixture\nimport("testing";"time")\nfunc TestTimeout(t *testing.T){time.Sleep(time.Second)}\n')
run_ooze('test-timeout', slow, 'fixture.go', timeout='100ms')
equiv = RUNTIME/'equivalent'; shutil.copytree(fixture,equiv)
(equiv/'fixture.go').write_text('package fixture\n\nfunc Less(x int) bool { return x < x }\n')
(equiv/'fixture_test.go').write_text('package fixture\nimport "testing"\nfunc TestEquivalent(t *testing.T){for _,x:=range []int{-1,0,1}{if Less(x){t.Fatal("irreflexive")}}}\n')
command('equivalent-baseline',['go','test','-json','-count=1','-timeout=5s','./...'],equiv)
run_ooze('equivalent',equiv,'fixture.go','equivalent')
(fixture/'sentinel.txt').write_text('original\n')
run_ooze('source-preservation',fixture,'fixture.go',mode='sentinel')
run_ooze('normal-descendant-cleanup',fixture,'fixture.go',mode='orphan',deadline=15)
run_ooze('cancellation',fixture,'fixture.go',mode='block',cancel=True,deadline=15)
run_ooze('outer-deadline',fixture,'fixture.go',mode='block',deadline=3)
run_ooze('discovery',subject,'pkg/types/entity_id.go',deadline=900)

# Replay the identical curated witness against saved mutant bytes, then restore by bytes/hash.
original = (subject/'pkg/types/entity_id.go').read_bytes()
mutant = (OUT/'positive/candidate-01/mutant.go.txt').read_bytes()
witness = 'testdata/rapid/TestPropEntityIDByteBound/TestPropEntityIDByteBound-20260831140043-41866.fail'
REPLAY = ['go','test','-json','-count=1','-parallel=1','-timeout=10s','-run=^TestPropEntityIDByteBound$',
          './pkg/types','-rapid.seed=1318','-rapid.nofailfile','-rapid.failfile='+witness]
command('paired-original',REPLAY,subject)
try:
    (subject/'pkg/types/entity_id.go').write_bytes(mutant)
    command('paired-mutant',REPLAY,subject)
finally:
    (subject/'pkg/types/entity_id.go').write_bytes(original)
command('paired-restored',REPLAY,subject)
command('final-race-baseline',TEST[:2]+['-race']+TEST[2:],subject,timeout=90)
write(OUT/'final-integrity.json', {'source_files_match_initial': hashes(subject)==json.loads((OUT/'source-manifest.json').read_text())['files'],
      'subject': str(subject), 'runtime_retained_for_inspection': str(RUNTIME)})
print('DONE', OUT, flush=True)
